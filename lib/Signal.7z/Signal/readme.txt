[This is ...]
C#で記述されたデジタル信号処理のライブラリです。
FFTができます。

[IDE] Visual Studio 2010

[Abst.]
周波数分析を簡単に実現するためのクラス群を含みます。

2013/5/11 Katsuhiro Morishita